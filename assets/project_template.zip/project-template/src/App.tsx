import './App.css'

function App() {
  return (
    <>
      <div>Hello Vite + React!</div>
    </>
  )
}

export default App
